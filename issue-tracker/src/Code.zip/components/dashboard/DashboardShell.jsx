"use client";

import { useEffect, useState } from "react";
import { Plus, FolderKanban, LogOut } from "lucide-react";
import { useRouter } from "next/navigation";

export default function DashboardShell({ user }) {
  const router = useRouter();

  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadProjects() {
      try {
        const response = await fetch("/api/project");

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Failed to fetch projects");
        }

        setProjects(data.projects || []);

        if (data.projects?.length > 0) {
          setSelectedProject(data.projects[0]);
        }
      } catch (error) {
        console.error("Failed to load projects:", error);
      } finally {
        setLoading(false);
      }
    }

    loadProjects();
  }, []);

  function handleProjectSelect(project) {
    setSelectedProject(project);
  }

  async function handleLogout() {
    await fetch("/api/auth/logout", {
      method: "POST",
    });

    router.push("/login");
    router.refresh();
  }

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-gray-100">
        <p className="text-gray-500">Loading dashboard...</p>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-100 text-gray-900">
      {/* HEADER */}
      <header className="flex h-16 items-center justify-between border-b bg-white px-2">
        <div>
          <h1 className="text-lg font-bold">
            Issue Tracker
          </h1>

          <p className="text-xs text-gray-500">
            Project Management
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-sm font-medium">
              {user.name}
            </p>

            <p className="text-xs text-gray-500">
              {user.email}
            </p>
          </div>

          <button
            onClick={handleLogout}
            className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm transition hover:bg-gray-100"
          >
            <LogOut size={16} />
            Logout
          </button>
        </div>
      </header>

      {/* MAIN */}
      <div className="flex min-h-[calc(100vh-4rem)]">

        {/* SIDEBAR */}
        <aside className="w-72 border-r bg-white p-5">

          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">
                Workspace
              </p>

              <h2 className="mt-1 text-lg font-bold">
                Projects
              </h2>
            </div>

            <button
              onClick={() => router.push("/dashboard/projects/new")}
              className="rounded-lg border p-2 transition hover:bg-gray-100"
              title="Create project"
            >
              <Plus size={18} />
            </button>
          </div>

          {/* PROJECT LIST */}

          <div className="space-y-2">

            {projects.length === 0 ? (
              <div className="rounded-xl border border-dashed p-5 text-center">
                <FolderKanban
                  size={28}
                  className="mx-auto text-gray-400"
                />

                <p className="mt-3 text-sm text-gray-500">
                  No projects yet
                </p>

                <button
                  onClick={() =>
                    router.push("/dashboard/projects/new")
                  }
                  className="mt-3 text-sm font-medium text-blue-600 hover:underline"
                >
                  Create your first project
                </button>
              </div>
            ) : (
              projects.map((project) => {
                const isSelected =
                  selectedProject?._id === project._id;

                return (
                  <button
                    key={project._id}
                    onClick={() =>
                      handleProjectSelect(project)
                    }
                    className={`w-full rounded-xl p-3 text-left transition ${
                      isSelected
                        ? "bg-gray-900 text-white"
                        : "hover:bg-gray-100"
                    }`}
                  >
                    <div className="flex items-center gap-3">

                      <div
                        className={`flex h-9 w-9 items-center justify-center rounded-lg ${
                          isSelected
                            ? "bg-white/10"
                            : "bg-gray-100"
                        }`}
                      >
                        <FolderKanban size={17} />
                      </div>

                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">
                          {project.name}
                        </p>

                        <p
                          className={`text-xs ${
                            isSelected
                              ? "text-gray-300"
                              : "text-gray-500"
                          }`}
                        >
                          {project.key}
                        </p>
                      </div>

                    </div>
                  </button>
                );
              })
            )}

          </div>
        </aside>

        {/* CONTENT */}

        <section className="flex-1 p-8">

          {!selectedProject ? (
            <div className="flex h-full items-center justify-center">
              <div className="text-center">
                <FolderKanban
                  size={40}
                  className="mx-auto text-gray-400"
                />

                <h2 className="mt-4 text-xl font-semibold">
                  Select a project
                </h2>

                <p className="mt-2 text-gray-500">
                  Choose a project from the sidebar to view its issues.
                </p>
              </div>
            </div>
          ) : (
            <div>

              {/* PROJECT HEADER */}

              <div className="mb-8">
                <p className="text-sm text-gray-500">
                  Selected project
                </p>

                <h2 className="mt-1 text-3xl font-bold">
                  {selectedProject.name}
                </h2>

                <p className="mt-2 max-w-2xl text-gray-500">
                  {selectedProject.description ||
                    "No project description available."}
                </p>
              </div>

              {/* PLACEHOLDER */}

              <div className="rounded-2xl border border-dashed bg-white p-12 text-center">
                <h3 className="text-xl font-semibold">
                  Project 
                </h3>

                <p className="mt-2 text-gray-500">
                  Issues and analytics will appear here.
                </p>
              </div>

            </div>
          )}

        </section>
      </div>
    </main>
  );
}
