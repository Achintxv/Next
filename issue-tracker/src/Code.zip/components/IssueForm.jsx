"use client";

import React, { useState, useEffect } from "react";

import { useRouter } from "next/navigation";

const IssueForm = () => {
  const router = useRouter();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [projectId, setProjectId] = useState("");
  const [status, setStatus] = useState("OPEN");

  const [projects, setProjects] = useState([]);
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const res = await fetch("/api/project");

        if (!res.ok) {
          throw new Error("Failed to fetch projects");
        }

        const data = await res.json();
        setProjects(data);
      } catch (error) {
        console.error(error);
        setError("Failed to load projects");
      } finally {
        setLoadingProjects(false);
      }
    };

    fetchProjects();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");

    if (!title.trim()) {
      setError("Title is required");
      return;
    }

    if (!projectId) {
      setError("Please select a project");
      return;
    }

    try {
      setSubmitting(true);

      const res = await fetch("/api/issue", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          projectId,
          status,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to create issue");
      }

      router.push("/issues");
      router.refresh();
    } catch (error) {
      console.error(error);
      setError(error.message || "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white/3 border border-zinc-700 rounded-2xl flex flex-col px-5 py-4 gap-6"
    >
      <div className="flex flex-col gap-4">

        {/* Title */}
        <div className="flex flex-col gap-2">
          <label className="text-white font-semibold">
            Title
          </label>

          <input
            type="text"
            placeholder="Enter issue title"
            className="bg-white/5 text-white border p-2 border-zinc-700 rounded-md focus:outline-none focus:border-blue-500 caret-zinc-500"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        {/* Project */}
        <div className="flex flex-col gap-2">
          <label className="text-white font-semibold">
            Project
          </label>

          <select
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
            disabled={loadingProjects}
            className="bg-zinc-900 text-white border p-2 border-zinc-700 rounded-md focus:outline-none focus:border-blue-500"
          >
            <option value="">
              {loadingProjects
                ? "Loading projects..."
                : "Select a project"}
            </option>

            {projects.map((project) => (
              <option key={project._id} value={project._id}>
                {project.key} — {project.name}
              </option>
            ))}
          </select>
        </div>

        {/* Status */}
        <div className="flex flex-col gap-2">
          <label className="text-white font-semibold">
            Status
          </label>

          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="bg-zinc-900 text-white border p-2 border-zinc-700 rounded-md focus:outline-none focus:border-blue-500"
          >
            <option value="OPEN">Open</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="CLOSED">Closed</option>
          </select>
        </div>

        {/* Description */}
        <div className="flex flex-col gap-2">
          <label className="text-white font-semibold">
            Description
          </label>

          <textarea
            placeholder="Describe the issue..."
            rows={5}
            className="bg-white/5 text-white border p-2 border-zinc-700 rounded-md focus:outline-none focus:border-blue-500 caret-zinc-500 resize-none"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
      </div>

      {/* Error */}
      {error && (
        <p className="text-red-400 text-sm">
          {error}
        </p>
      )}

      {/* Submit */}
      <button
        type="submit"
        disabled={submitting || loadingProjects}
        className="bg-blue-600 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer text-white w-fit px-5 py-2 rounded-md transition"
      >
        {submitting ? "Creating..." : "Post Issue"}
      </button>
    </form>
  );
};

export default IssueForm;