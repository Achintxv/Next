"use client";

import { useEffect, useState } from "react";
import { Plus, FolderKanban } from "lucide-react";
import { useRouter } from "next/navigation";

const page = () => {
  const router = useRouter();

  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadProjects() {
      try {
        const response = await fetch("/api/project");

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Failed to fetch projects");
        }

        setProjects(data.projects || []);

        if (data.projects?.length > 0) {
          setSelectedProject(data.projects[0]);
        }
      } catch (error) {
        console.error("Failed to load projects:", error);
      } finally {
        setLoading(false);
      }
    }
    loadProjects();
  }, []);

  return <div>
    <div className="flex flex-col p-2 bg-zinc-500">
        <input type="text" placeholder="name"/>
        <input type="text" placeholder="title"/>
        <input type="text" placeholder="status"/>
    </div>
  </div>;
};

export default page;
