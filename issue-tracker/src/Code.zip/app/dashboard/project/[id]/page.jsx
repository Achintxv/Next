import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import Project from "@/models/project";

export default async function ProjectDashboard({ params }) {
  const user = await getCurrentUser();

  if (!user) {
    notFound();
  }

  await connectDB();

  const { id } = await params;

  const project = await Project.findOne({
    _id: id,
    ownerId: user._id,
  }).lean();

  if (!project) {
    notFound();
  }

  return (
    <div className="text-white">
      <h1 className="text-3xl font-semibold">
        {project.name}
      </h1>

      <p className="text-zinc-400 mt-2">
        {project.description || "No description"}
      </p>

      <div className="mt-4 text-sm text-zinc-500">
        Project key: {project.key}
      </div>

      <div className="mt-8">
        <button className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-md">
          New Issue
        </button>
      </div>
    </div>
  );
}