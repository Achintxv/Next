"use client";

import { useEffect, useState } from "react";
import ExpandableList from "@/components/ui/ExpandableList";
import Dropdown from "@/components/ui/Dropdown";
import Link from "next/link";

export default function IssuesPage() {
  const [issues, setIssues] = useState([]);
  const [statusFilter, setStatusFilter] = useState("ALL");
  const fetchIssues = async (status = "ALL") => {
    try {
      const res = await fetch(`/api/issue?status=${status}`);
      if (!res.ok) {
        console.error("Request failed:", res.status);
        return;
      }
      const data = await res.json();
      setIssues(data);
    } catch (error) {
      console.error("Failed to fetch issues:", error);
    }
  };

  useEffect(() => {
    fetchIssues(statusFilter);
  }, [statusFilter]);
  const dropItem = ["ALL", "OPEN", "IN_PROGRESS", "CLOSED"];

  return (
    <div className="text-white flex flex-col gap-5">
      <div className="flex justify-between px-2">
        <Dropdown
          dropItem={dropItem}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
        />
        <Link
          href="/issues/new"
          className="px-3 py-1 flex items-center bg-blue-600 rounded-md hover:bg-blue-800 transition"
        >
          New Issue
        </Link>
      </div>
      <div>
        <ExpandableList issue={issues} fetchIssue={fetchIssues} />
      </div>
    </div>
  );
}
